﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAppModel.DAL;
using WebAppModel.Models;
using WebAppModel.ViewModels;

namespace WebAppModel.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            #region ViewData,Viewbag,TempData
            //ViewData["Name"] = "Fikret1";
            //ViewBag.Surname = "Javadov";
            //TempData["Age"] = 25;
            //if (int.Parse(TempData["Age"].ToString()) > 18)
            //{
            //    return RedirectToAction("About");
            //}
            #endregion

            //List<Student> students = new List<Student>
            //{
            //    new Student{Id=1,Name="Javid",Surname="Mecidov"},
            //    new Student{Id=2,Name="Kenan",Surname="Memmedli"},
            //    new Student{Id=3,Name="MuhammedAli",Surname="Abbaszade"},
            //    new Student{Id=4,Name="Tural",Surname="Alesgerli"}
            //};
            List<int> numbers = new List<int> { 10, 20, 30, 40, 50 };

            string GroupName = "P315";

            HomeVM homeVM = new HomeVM()
            {
                Students = _context.Students.ToList(),
                Numbers = numbers,
                Group = GroupName
            };
            //homeVM.Students = students;
            //homeVM.Numbers = numbers;
            //homeVM.Group = GroupName;
            
            return View(homeVM);
        }

        public IActionResult About()
        {
            return View();
        }
    }
}